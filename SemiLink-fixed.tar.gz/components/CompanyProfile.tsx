
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Users, Globe, MapPin, Plus, Check, Camera, ExternalLink, Briefcase, DollarSign, Search, Building2, User } from 'lucide-react';
import { Company, Job } from '../types';
import { MOCK_JOBS, MOCK_SUGGESTIONS } from '../constants';

interface CompanyProfileProps {
  company: Company;
  onBack: () => void;
  onJobClick?: (job: Job) => void;
  savedJobs: Set<string>;
  onToggleSaveJob: (jobId: string) => void;
}

const CompanyProfile: React.FC<CompanyProfileProps> = ({ company, onBack, onJobClick, savedJobs, onToggleSaveJob }) => {
  const companyJobs = MOCK_JOBS.filter(job => job.company === company.name);
  const [isFollowing, setIsFollowing] = useState(false);
  const [bannerUrl, setBannerUrl] = useState(company.banner);
  const [activeTab, setActiveTab] = useState('home');

  const uniqueJobTitles = Array.from(new Set(companyJobs.map(job => job.title)));

  useEffect(() => {
    setBannerUrl(company.banner);
    setIsFollowing(false);
    setActiveTab('home');
  }, [company]);

  const handleUpdateBanner = () => {
    const randomId = Math.floor(Math.random() * 1000);
    setBannerUrl(`https://picsum.photos/800/200?random=${randomId}`);
  };

  return (
    <div className="space-y-4">
      <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 overflow-hidden relative">
        <button
          onClick={onBack}
          className="absolute top-4 left-4 z-10 bg-black/40 hover:bg-black/60 text-white p-2 rounded-full backdrop-blur-sm transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="h-40 bg-gray-800 relative group">
          <img
            src={bannerUrl}
            alt={`${company.name} banner`}
            className="w-full h-full object-cover transition-opacity duration-300"
          />
          <button
            onClick={handleUpdateBanner}
            className="absolute top-4 right-4 z-10 p-2 bg-[#252a3a] text-gray-300 rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-all duration-200 hover:text-blue-400 hover:bg-[#2e3447]"
            title="Update cover photo"
          >
            <Camera className="w-5 h-5" />
          </button>
          <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
        </div>

        <div className="px-6 pt-0 pb-0 relative">
          <div className="absolute -top-16 left-6 p-2 bg-[#1e2130] rounded-xl shadow-lg border border-gray-700 z-10">
            <img
              src={company.logo}
              alt={company.name}
              className="w-32 h-32 rounded-lg object-contain bg-[#252a3a]"
            />
          </div>

          <div className="pt-20 pb-6 flex flex-col md:flex-row md:items-start justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-100">{company.name}</h1>
              <p className="text-gray-400 mt-1">{company.industry}</p>

              <div className="flex flex-wrap items-center gap-4 mt-3 text-sm text-gray-400">
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" /> {company.headquarters}
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-4 h-4" /> {company.followers.toLocaleString()} followers
                </span>
                <a
                  href={company.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-blue-400 hover:underline"
                >
                  <Globe className="w-4 h-4" /> Website
                </a>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setIsFollowing(!isFollowing)}
                className={`flex items-center gap-1 px-4 py-1.5 rounded-full font-semibold border transition-colors ${
                  isFollowing
                    ? 'border-gray-600 text-gray-400 bg-[#1e2130] hover:bg-[#252a3a]'
                    : 'bg-blue-600 text-white border-transparent hover:bg-blue-700'
                }`}
              >
                {isFollowing ? <><Check className="w-4 h-4"/> Following</> : <><Plus className="w-4 h-4"/> Follow</>}
              </button>
              <a
                href={company.website}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-1.5 text-blue-400 font-semibold border border-blue-500 rounded-full hover:bg-blue-900/30 transition-colors flex items-center justify-center gap-2"
              >
                Visit website <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        <div className="px-6 flex gap-1 border-t border-gray-700">
          {['Home', 'About', 'Jobs', 'People'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab.toLowerCase())}
              className={`px-4 py-3 text-sm font-semibold border-b-2 transition-colors ${
                activeTab === tab.toLowerCase()
                  ? 'border-green-500 text-green-400'
                  : 'border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#252a3a]'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'home' && (
        <>
          <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 p-6">
            <h2 className="text-lg font-bold text-gray-100 mb-3">About</h2>
            <p className="text-gray-300 leading-relaxed whitespace-pre-wrap line-clamp-4">
              {company.description}
            </p>
            <button
              onClick={() => setActiveTab('about')}
              className="mt-2 text-blue-400 font-semibold hover:underline text-sm"
            >
              See all details
            </button>
          </div>

          {companyJobs.length > 0 && (
            <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 p-6">
              <div className="flex justify-between items-center mb-3">
                <h2 className="text-lg font-bold text-gray-100">Recently Posted Jobs</h2>
                <button
                  onClick={() => setActiveTab('jobs')}
                  className="text-sm font-semibold text-blue-400 hover:underline"
                >
                  See all jobs
                </button>
              </div>
              <div className="space-y-3">
                {companyJobs.slice(0, 3).map(job => (
                  <div
                    key={job.id}
                    className="flex justify-between items-center border-b border-gray-700 pb-2 last:border-0 last:pb-0 hover:bg-[#252a3a] -mx-2 px-2 rounded transition-colors cursor-pointer"
                    onClick={() => onJobClick && onJobClick(job)}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500 flex-shrink-0"></div>
                      <span className="text-sm font-medium text-gray-200 hover:text-blue-400 line-clamp-1">{job.title}</span>
                    </div>
                    <span className="text-xs text-gray-500 flex-shrink-0 whitespace-nowrap ml-2">{job.postedTime}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {activeTab === 'jobs' && (
        <>
          {uniqueJobTitles.length > 0 && (
            <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 p-6">
              <div className="flex items-center gap-2 mb-3">
                <Briefcase className="w-5 h-5 text-gray-500" />
                <h2 className="text-lg font-bold text-gray-100">Roles we are hiring for</h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {uniqueJobTitles.map((title) => (
                  <span
                    key={title}
                    className="px-3 py-1.5 bg-gray-800 text-gray-300 rounded-full text-sm font-medium border border-gray-700"
                  >
                    {title}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 p-6">
            <h2 className="text-lg font-bold text-gray-100 mb-4">
              Open Positions <span className="text-gray-500 font-normal text-base ml-1">({companyJobs.length})</span>
            </h2>

            {companyJobs.length > 0 ? (
              <div className="space-y-4">
                {companyJobs.map(job => (
                  <div key={job.id} className="flex justify-between items-start pb-4 border-b border-gray-700 last:border-0 last:pb-0">
                    <div className="space-y-1 flex-1">
                      <h3
                        className="font-semibold text-blue-400 hover:underline cursor-pointer text-base"
                        onClick={() => onJobClick && onJobClick(job)}
                      >
                        {job.title}
                      </h3>
                      <div className="text-sm text-gray-300">
                        {job.location} ({job.type})
                      </div>

                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1 text-sm text-gray-400">
                        <span className="flex items-center gap-1.5">
                          <Briefcase className="w-3.5 h-3.5 text-gray-500" />
                          {job.experienceLevel}
                        </span>
                        {job.salaryRange && (
                          <span className="flex items-center gap-1 text-green-400 bg-green-900/30 px-2 py-0.5 rounded text-xs font-medium border border-green-800">
                            <DollarSign className="w-3 h-3" />
                            {job.salaryRange}
                          </span>
                        )}
                      </div>

                      <div className="text-xs text-gray-500 mt-2 pt-1">
                        Posted {job.postedTime} • {job.applicants} applicants
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-2 ml-4">
                      <button
                        onClick={(e) => { e.stopPropagation(); onToggleSaveJob(job.id); }}
                        className={`px-4 py-1.5 font-semibold border rounded-full transition-colors text-sm whitespace-nowrap ${
                          savedJobs.has(job.id)
                            ? 'border-blue-500 text-blue-400 bg-blue-900/30'
                            : 'border-gray-600 text-gray-400 hover:bg-[#252a3a]'
                        }`}
                      >
                        {savedJobs.has(job.id) ? 'Saved' : 'Save'}
                      </button>
                      <button className="px-4 py-1.5 text-blue-400 font-semibold border border-blue-500 rounded-full hover:bg-blue-900/30 transition-colors text-sm whitespace-nowrap">
                        Apply
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-gray-500 text-sm">No open positions at the moment.</div>
            )}
          </div>
        </>
      )}

      {activeTab === 'about' && (
        <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 p-6">
          <h2 className="text-xl font-bold text-gray-100 mb-4">About {company.name}</h2>
          <p className="text-gray-300 leading-relaxed whitespace-pre-wrap mb-6">
            {company.description}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-gray-700 pt-6">
            <div>
              <h3 className="font-semibold text-gray-100 text-sm">Website</h3>
              <a href={company.website} target="_blank" rel="noopener noreferrer" className="text-blue-400 text-sm hover:underline">
                {company.website}
              </a>
            </div>
            <div>
              <h3 className="font-semibold text-gray-100 text-sm">Industry</h3>
              <p className="text-gray-300 text-sm">{company.industry}</p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-100 text-sm">Headquarters</h3>
              <p className="text-gray-300 text-sm">{company.headquarters}</p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-100 text-sm">Company size</h3>
              <p className="text-gray-300 text-sm">10,001+ employees</p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'people' && (
        <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 p-6">
          <h2 className="text-xl font-bold text-gray-100 mb-4">People</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-gray-700 rounded-lg p-4 bg-[#161925] text-center">
              <h3 className="text-2xl font-bold text-gray-100">{company.followers.toLocaleString()}</h3>
              <p className="text-sm text-gray-400">Employees on SemiLink</p>
            </div>
            <div className="border border-gray-700 rounded-lg p-4 bg-[#161925] text-center">
              <h3 className="text-2xl font-bold text-gray-100">42</h3>
              <p className="text-sm text-gray-400">Friends work here</p>
            </div>
          </div>

          <h3 className="text-lg font-bold text-gray-100 mt-6 mb-4">People you may know</h3>
          <div className="space-y-4">
            {MOCK_SUGGESTIONS.slice(0, 3).map(person => (
              <div key={person.id} className="flex items-center justify-between border-b border-gray-700 pb-3 last:border-0 last:pb-0">
                <div className="flex items-center gap-3">
                  <img src={person.avatarUrl} alt={person.name} className="w-12 h-12 rounded-full object-cover" />
                  <div>
                    <h4 className="font-bold text-gray-100">{person.name}</h4>
                    <p className="text-xs text-gray-400">{person.headline}</p>
                  </div>
                </div>
                <button className="px-4 py-1.5 rounded-full border border-blue-500 text-blue-400 text-sm font-semibold hover:bg-blue-900/30">
                  Connect
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CompanyProfile;
