
import React, { useMemo } from 'react';
import CreatePost from './CreatePost';
import PostCard from './PostCard';
import { MOCK_COMPANIES, MOCK_INVITATIONS, MOCK_SUGGESTIONS, CURRENT_USER } from '../constants';
import { Post, User } from '../types';
import { Building2, ArrowRight, Users } from 'lucide-react';

interface FeedProps {
  posts: Post[];
  onPostCreated: (post: Post) => void;
  onPostLike: (postId: string) => void;
  searchQuery: string;
  onCompanyClick?: (companyName: string) => void;
  onUserClick?: (user: User) => void;
  user?: User;
}

const Feed: React.FC<FeedProps> = ({ posts, onPostCreated, onPostLike, searchQuery, onCompanyClick, onUserClick, user }) => {
  const filteredPosts = posts.filter((post) => {
    const query = searchQuery.toLowerCase();
    return (
      post.content.toLowerCase().includes(query) ||
      post.author.name.toLowerCase().includes(query) ||
      post.tags.some(tag => tag.toLowerCase().includes(query))
    );
  });

  const filteredCompanies = searchQuery
    ? MOCK_COMPANIES.filter((company) =>
        company.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const allUsers = useMemo(() => {
    const users = new Map<string, User>();
    const activeUser = user || CURRENT_USER;
    users.set(activeUser.id, activeUser);

    posts.forEach(p => users.set(p.author.id, p.author));
    MOCK_SUGGESTIONS.forEach(u => users.set(u.id, u));
    MOCK_INVITATIONS.forEach(u => users.set(u.id, u));
    return Array.from(users.values());
  }, [user, posts]);

  const filteredPeople = searchQuery
    ? allUsers.filter((u) =>
        u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        u.headline.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <div>
      <CreatePost onPostCreated={onPostCreated} currentUser={user} />

      {searchQuery && (
        <div className="mb-4 space-y-4">
          <div className="flex items-center justify-between mb-2 px-1">
            <h3 className="text-sm font-semibold text-gray-400">Search Results</h3>
          </div>

          {filteredPeople.length > 0 && (
            <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-700 flex items-center gap-2 bg-[#161925]">
                <Users className="w-4 h-4 text-gray-500" />
                <h4 className="text-sm font-semibold text-gray-200">People</h4>
              </div>
              <div>
                {filteredPeople.slice(0, 3).map(person => (
                  <div
                    key={person.id}
                    className="p-4 hover:bg-[#252a3a] flex items-center justify-between cursor-pointer transition-colors border-b border-gray-700 last:border-0"
                    onClick={() => onUserClick && onUserClick(person)}
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={person.avatarUrl}
                        alt={person.name}
                        className="w-12 h-12 rounded-full object-cover border border-gray-700"
                      />
                      <div>
                        <h4 className="font-bold text-gray-100 text-base">{person.name}</h4>
                        <p className="text-xs text-gray-400 line-clamp-1">{person.headline}</p>
                      </div>
                    </div>
                    <button className="text-semi-400 hover:bg-semi-900/30 p-2 rounded-full">
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                ))}
                {filteredPeople.length > 3 && (
                  <div className="p-2 text-center border-t border-gray-700">
                    <button className="text-sm text-blue-400 font-semibold hover:underline">See all {filteredPeople.length} people results</button>
                  </div>
                )}
              </div>
            </div>
          )}

          {filteredCompanies.length > 0 && (
            <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-700 flex items-center gap-2 bg-[#161925]">
                <Building2 className="w-4 h-4 text-gray-500" />
                <h4 className="text-sm font-semibold text-gray-200">Companies</h4>
              </div>
              <div>
                {filteredCompanies.map(company => (
                  <div
                    key={company.id}
                    className="p-4 hover:bg-[#252a3a] flex items-center justify-between cursor-pointer transition-colors border-b border-gray-700 last:border-0"
                    onClick={() => onCompanyClick && onCompanyClick(company.name)}
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={company.logo}
                        alt={company.name}
                        className="w-12 h-12 object-contain border border-gray-700 rounded-lg bg-[#252a3a]"
                      />
                      <div>
                        <h4 className="font-bold text-gray-100 text-base">{company.name}</h4>
                        <p className="text-xs text-gray-400">{company.industry} • {company.headquarters}</p>
                      </div>
                    </div>
                    <button className="text-semi-400 hover:bg-semi-900/30 p-2 rounded-full">
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <div className="flex items-center justify-between mb-2">
        <div className="h-[1px] bg-gray-700 flex-1"></div>
        <span className="text-xs text-gray-500 px-2">Sort by: <strong className="text-gray-100 cursor-pointer">Top</strong></span>
      </div>

      {filteredPosts.length > 0 ? (
        filteredPosts.map((post) => (
          <PostCard key={post.id} post={post} onLike={onPostLike} onUserClick={onUserClick} />
        ))
      ) : (
        <div className="text-center py-10 text-gray-500">
          {searchQuery && filteredCompanies.length === 0 && filteredPeople.length === 0 ? (
            <p>No posts, people, or companies found matching "{searchQuery}"</p>
          ) : searchQuery && (filteredCompanies.length > 0 || filteredPeople.length > 0) ? (
            <p className="text-sm mt-4">No posts found matching "{searchQuery}", but check the results above.</p>
          ) : (
            <p>No posts to display.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default Feed;
