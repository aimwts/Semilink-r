
import React from 'react';
import { Search, Home, Users, Briefcase, MessageSquare, Bell, Cpu, LogOut, Github } from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onSearch: (query: string) => void;
  searchQuery: string;
  user?: User;
  onLogout?: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate, onSearch, searchQuery, user, onLogout }) => {
  return (
    <nav className="bg-[#1e2130] border-b border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-14">
          <div className="flex items-center">
            <div
              className="flex-shrink-0 flex items-center cursor-pointer"
              onClick={() => onNavigate('home')}
            >
              <Cpu className="h-8 w-8 text-semi-400" />
              <span className="ml-2 text-xl font-bold text-semi-300 hidden md:block">SemiLink</span>
            </div>
            <div className="hidden md:ml-6 md:flex md:items-center">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-500" />
                </div>
                <input
                  type="text"
                  className="block w-64 pl-10 pr-3 py-1.5 border border-gray-600 rounded-md leading-5 bg-[#252a3a] text-gray-100 placeholder-gray-500 focus:outline-none focus:bg-[#2e3447] focus:ring-1 focus:ring-semi-500 focus:border-semi-500 sm:text-sm transition duration-150 ease-in-out"
                  placeholder="Search for chips, companies, or people"
                  value={searchQuery}
                  onChange={(e) => onSearch(e.target.value)}
                />
              </div>
            </div>
          </div>
          <div className="flex items-center justify-end space-x-2 sm:space-x-6 md:space-x-8">
            <NavItem
              icon={<Home className="h-6 w-6" />}
              label="Home"
              active={currentView === 'home'}
              onClick={() => onNavigate('home')}
            />
            <NavItem
              icon={<Users className="h-6 w-6" />}
              label="My Network"
              active={currentView === 'network'}
              onClick={() => onNavigate('network')}
            />
            <NavItem
              icon={<Briefcase className="h-6 w-6" />}
              label="Jobs"
              active={currentView === 'jobs' || currentView === 'job' || currentView === 'company'}
              onClick={() => onNavigate('jobs')}
            />
            <NavItem
              icon={<MessageSquare className="h-6 w-6" />}
              label="Messaging"
              active={currentView === 'messaging'}
              onClick={() => onNavigate('messaging')}
            />
            <NavItem
              icon={<Bell className="h-6 w-6" />}
              label="Notifications"
              active={currentView === 'notifications'}
              onClick={() => onNavigate('notifications')}
            />

            <div className="border-l border-gray-700 h-8 mx-2 hidden md:block"></div>

            <div
              className={`flex flex-col items-center cursor-pointer ${currentView === 'profile' ? 'border-b-2 border-gray-100' : ''}`}
              onClick={() => onNavigate('profile')}
            >
              <img
                className="h-6 w-6 rounded-full object-cover"
                src={user?.avatarUrl || "https://picsum.photos/150/150?random=1"}
                alt="Profile"
              />
              <span className={`hidden md:block text-xs mt-1 ${currentView === 'profile' ? 'text-gray-100' : 'text-gray-400'}`}>Me</span>
            </div>

            <a
              href="https://github.com/google-gemini/semilink-demo"
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center cursor-pointer text-gray-400 hover:text-gray-100"
              title="View on GitHub"
            >
              <div className="mt-1"><Github className="h-6 w-6" /></div>
              <span className="hidden md:block text-xs mt-1">Source</span>
            </a>

            {onLogout && (
              <div
                className="flex flex-col items-center cursor-pointer text-gray-400 hover:text-red-400"
                onClick={onLogout}
                title="Sign Out"
              >
                <LogOut className="h-6 w-6" />
                <span className="hidden md:block text-xs mt-1">Sign Out</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon, label, active, onClick }) => {
  return (
    <div
      className={`flex flex-col items-center cursor-pointer ${active ? 'text-gray-100 border-b-2 border-gray-100' : 'text-gray-400 hover:text-gray-100'}`}
      onClick={onClick}
    >
      <div className="mt-1">{icon}</div>
      <span className="hidden md:block text-xs mt-1">{label}</span>
    </div>
  );
};

export default Navbar;
