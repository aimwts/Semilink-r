
import React, { useState } from 'react';
import { UserPlus, X, Users, Briefcase } from 'lucide-react';
import { User } from '../types';

interface NetworkProps {
  invitations: User[];
  suggestions: User[];
  connectedIds: Set<string>;
  onAccept: (userId: string) => void;
  onIgnore: (userId: string) => void;
  onConnect: (userId: string) => void;
}

const Network: React.FC<NetworkProps> = ({ invitations, suggestions, connectedIds, onAccept, onIgnore, onConnect }) => {
  return (
    <div className="space-y-4">
      <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-700 flex justify-between items-center">
          <h2 className="text-base font-semibold text-gray-100">Invitations</h2>
          <button className="text-sm font-semibold text-gray-400 hover:text-gray-200 hover:bg-[#252a3a] px-2 py-1 rounded">
            Manage
          </button>
        </div>

        {invitations.length > 0 ? (
          <div>
            {invitations.map((inv) => (
              <div key={inv.id} className="p-4 border-b border-gray-700 last:border-0 flex items-center justify-between hover:bg-[#252a3a] transition-colors">
                <div className="flex items-center gap-4">
                  <img
                    src={inv.avatarUrl}
                    alt={inv.name}
                    className="w-16 h-16 rounded-full object-cover border border-gray-700"
                  />
                  <div>
                    <h3 className="font-semibold text-gray-100 text-base">{inv.name}</h3>
                    <p className="text-sm text-gray-400 line-clamp-1">{inv.headline}</p>
                    {inv.mutualConnections && (
                      <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                        <Users className="w-3 h-3" /> {inv.mutualConnections} mutual connections
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onIgnore(inv.id)}
                    className="px-4 py-1.5 text-gray-400 font-semibold hover:bg-[#252a3a] rounded-full transition-colors"
                  >
                    Ignore
                  </button>
                  <button
                    onClick={() => onAccept(inv.id)}
                    className="px-4 py-1.5 text-blue-400 border border-blue-500 font-semibold hover:bg-blue-900/30 rounded-full transition-colors"
                  >
                    Accept
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 text-center text-gray-500">
            <p>No pending invitations.</p>
          </div>
        )}
      </div>

      <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-base font-semibold text-gray-100">People you may know in Semiconductor Industry</h2>
          <button className="text-sm font-semibold text-gray-400 hover:text-gray-200">See all</button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {suggestions.map((user) => (
            <div key={user.id} className="border border-gray-700 rounded-lg overflow-hidden flex flex-col items-center pb-4 hover:shadow-md hover:shadow-black/30 transition-shadow bg-[#1e2130]">
              <div className="h-16 w-full bg-gradient-to-r from-gray-700 to-gray-600 relative">
                <button className="absolute top-2 right-2 text-gray-400 hover:bg-black/20 p-1 rounded-full">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="-mt-10 mb-2">
                <img
                  src={user.avatarUrl}
                  alt={user.name}
                  className="w-20 h-20 rounded-full object-cover border-4 border-[#1e2130] cursor-pointer"
                />
              </div>

              <div className="text-center px-4 mb-4 flex-1">
                <h3 className="font-semibold text-gray-100 text-sm hover:underline cursor-pointer line-clamp-1">{user.name}</h3>
                <p className="text-xs text-gray-400 mt-1 line-clamp-2 min-h-[2.5em]">{user.headline}</p>
                {user.mutualConnections ? (
                  <p className="text-xs text-gray-500 mt-2 flex items-center justify-center gap-1">
                    <Users className="w-3 h-3" /> {user.mutualConnections} mutual connections
                  </p>
                ) : (
                  <p className="text-xs text-gray-500 mt-2 flex items-center justify-center gap-1">
                    <Briefcase className="w-3 h-3" /> Based on your profile
                  </p>
                )}
              </div>

              <div className="px-4 w-full">
                <button
                  onClick={() => onConnect(user.id)}
                  disabled={connectedIds.has(user.id)}
                  className={`w-full py-1.5 rounded-full font-semibold border flex items-center justify-center gap-1 transition-colors ${
                    connectedIds.has(user.id)
                      ? 'bg-[#1e2130] text-gray-500 border-gray-600 cursor-default'
                      : 'bg-[#1e2130] text-blue-400 border-blue-500 hover:bg-blue-900/30'
                  }`}
                >
                  {connectedIds.has(user.id) ? 'Pending' : <><UserPlus className="w-4 h-4" /> Connect</>}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Network;
