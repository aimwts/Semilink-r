
import React, { useState } from 'react';
import { ThumbsUp, MessageSquare, Share2, Send, MoreHorizontal } from 'lucide-react';
import { Post, User } from '../types';

interface PostCardProps {
  post: Post;
  onLike?: (postId: string) => void;
  onUserClick?: (user: User) => void;
}

const PostCard: React.FC<PostCardProps> = ({ post, onLike, onUserClick }) => {
  const [isFollowing, setIsFollowing] = useState(false);

  const handleLike = () => {
    if (onLike) {
      onLike(post.id);
    }
  };

  const handleFollow = () => {
    setIsFollowing(!isFollowing);
  };

  return (
    <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 mb-4 overflow-hidden">
      <div className="p-4 flex items-start gap-3">
        <img
          src={post.author.avatarUrl}
          alt={post.author.name}
          className="w-12 h-12 rounded-full object-cover cursor-pointer hover:opacity-90"
          onClick={() => onUserClick && onUserClick(post.author)}
        />
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h3
                  className="font-semibold text-gray-100 text-sm hover:text-blue-400 hover:underline cursor-pointer"
                  onClick={() => onUserClick && onUserClick(post.author)}
                >
                  {post.author.name}
                </h3>
                <span className="text-gray-600 text-xs">•</span>
                <button
                  onClick={handleFollow}
                  className="text-blue-400 text-xs font-semibold hover:underline flex items-center"
                >
                  {isFollowing ? 'Following' : 'Follow'}
                </button>
              </div>
              <p className="text-xs text-gray-400 line-clamp-1">{post.author.headline}</p>
              <div className="flex items-center gap-1 text-xs text-gray-500 mt-0.5">
                <span>{post.timestamp}</span>
                <span>•</span>
                <span className="font-medium">Global</span>
              </div>
            </div>
            <button className="text-gray-500 hover:bg-[#252a3a] p-1 rounded-full">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="px-4 pb-2">
        <p className="text-sm text-gray-200 whitespace-pre-wrap">{post.content}</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {post.tags.map(tag => (
            <span key={tag} className="text-xs text-semi-400 hover:underline cursor-pointer">#{tag}</span>
          ))}
        </div>
      </div>

      {post.imageUrl && (
        <div className="mt-2">
          <img src={post.imageUrl} alt="Post content" className="w-full object-cover max-h-96" />
        </div>
      )}

      {post.videoUrl && (
        <div className="mt-2 bg-black">
          <video src={post.videoUrl} className="w-full max-h-[500px]" controls />
        </div>
      )}

      <div className="px-4 py-2 border-b border-gray-700 flex items-center justify-between text-xs text-gray-500">
        <div className="flex items-center gap-1">
          {post.likes > 0 && (
            <>
              <div className="bg-blue-800/50 p-0.5 rounded-full">
                <ThumbsUp className="w-3 h-3 text-blue-400 fill-current" />
              </div>
              <span>{post.likes}</span>
            </>
          )}
        </div>
        <div>
          <span className="hover:text-blue-400 hover:underline cursor-pointer">{post.comments} comments</span>
        </div>
      </div>

      <div className="px-2 py-1 flex items-center justify-between">
        <ActionButton
          icon={<ThumbsUp className={`w-5 h-5 ${post.isLikedByCurrentUser ? 'text-blue-400 fill-current' : ''}`} />}
          label="Like"
          active={post.isLikedByCurrentUser}
          onClick={handleLike}
        />
        <ActionButton icon={<MessageSquare className="w-5 h-5" />} label="Comment" />
        <ActionButton icon={<Share2 className="w-5 h-5" />} label="Repost" />
        <ActionButton icon={<Send className="w-5 h-5" />} label="Send" />
      </div>
    </div>
  );
};

const ActionButton: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; onClick?: () => void }> = ({ icon, label, active, onClick }) => (
  <button
    onClick={onClick}
    className={`flex-1 flex items-center justify-center gap-2 py-3 hover:bg-[#252a3a] rounded-md transition-colors group ${active ? 'text-blue-400' : 'text-gray-400'}`}
  >
    <div className={`transition-colors ${active ? 'text-blue-400' : 'group-hover:text-gray-100'}`}>{icon}</div>
    <span className={`text-sm font-medium transition-colors ${active ? 'text-blue-400' : 'group-hover:text-gray-100'}`}>{label}</span>
  </button>
);

export default PostCard;
