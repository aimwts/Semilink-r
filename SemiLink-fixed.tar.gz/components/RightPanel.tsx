
import React from 'react';
import { Info, ArrowRight } from 'lucide-react';
import { NEWS_ITEMS } from '../constants';

const RightPanel: React.FC = () => {
  return (
    <div className="bg-[#1e2130] rounded-lg shadow-sm border border-gray-700 p-4 sticky top-20">
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-bold text-gray-100 text-sm">SemiLink News</h2>
        <Info className="w-4 h-4 text-gray-500 cursor-pointer fill-current" />
      </div>

      <ul className="space-y-4">
        {NEWS_ITEMS.map((item) => (
          <li key={item.id} className="cursor-pointer group">
            <a
              href={`https://www.google.com/search?q=${encodeURIComponent(item.title + ' semiconductor news')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-start gap-2 block"
            >
              <span className="w-2 h-2 rounded-full bg-gray-600 mt-1.5 group-hover:bg-semi-500 flex-shrink-0"></span>
              <div>
                <h3 className="text-sm font-semibold text-gray-200 group-hover:text-blue-400 group-hover:underline leading-snug">
                  {item.title}
                </h3>
                <div className="flex items-center text-xs text-gray-500 mt-1 gap-1">
                  <span>{item.time}</span>
                  <span>•</span>
                  <span>{item.readers.toLocaleString()} readers</span>
                </div>
              </div>
            </a>
          </li>
        ))}
      </ul>

      <button className="mt-4 flex items-center gap-1 text-sm text-gray-400 font-semibold hover:bg-[#252a3a] px-2 py-1 rounded transition-colors">
        Show more <ArrowRight className="w-4 h-4" />
      </button>

      <div className="mt-6 pt-4 border-t border-gray-700 text-center">
        <p className="text-xs text-gray-500 mb-2">Promoted</p>
        <div className="flex items-center justify-center gap-3 cursor-pointer">
          <div className="w-12 h-12 bg-gray-700 rounded-md"></div>
          <div className="text-left">
            <p className="text-xs font-bold text-gray-200">Master Verilog Today</p>
            <p className="text-xs text-gray-500">Join 5000+ engineers</p>
          </div>
        </div>
        <button className="mt-3 text-blue-400 text-sm font-semibold border border-blue-500 rounded-full px-4 py-1 hover:bg-blue-900/30 transition-colors">
          Learn more
        </button>
      </div>
    </div>
  );
};

export default RightPanel;
